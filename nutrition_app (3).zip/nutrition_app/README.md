# 🥗 NutriTrack

App web para registrar tus ingestas diarias y ver tus macros.

---

## 🚀 Cómo usar localmente (en tu computadora)

### 1. Instalá Python
Descargalo desde https://python.org (marcá "Add to PATH" al instalar)

### 2. Abrí una terminal en la carpeta del proyecto y ejecutá:

```bash
pip install -r requirements.txt
python app.py
```

### 3. Abrí el navegador en:
```
http://localhost:5000
```

---

## 🌐 Cómo deployar en Render (acceso desde el celular)

1. Creá una cuenta gratis en https://render.com
2. Subí esta carpeta a GitHub (también gratis)
3. En Render, hacé clic en "New Web Service" y conectá tu repo de GitHub
4. Render detecta el `render.yaml` y configura todo automáticamente
5. En unos minutos tenés una URL pública para usar desde tu celular

---

## 📱 Funciones disponibles

- **Hoy**: resumen de calorías y macros del día
- **Registrar**: agregar una ingesta con cantidad en gramos
- **Alimentos**: tu base de datos personal (nombre + valores por 100g)
- **Historial**: ver los últimos 30 días

---

## 🔮 Próximas funciones planeadas

- [ ] Escáner de etiquetas nutricionales por foto
- [ ] Objetivos de macros personalizados
- [ ] Recomendaciones según entrenamiento del día

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
import os
import base64
import json
import anthropic
from datetime import date

app = Flask(__name__)
app.secret_key = "nutrition_secret_key"

DB_PATH = "nutrition.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS foods (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            name     TEXT NOT NULL UNIQUE,
            calories REAL NOT NULL,
            protein  REAL NOT NULL,
            carbs    REAL NOT NULL,
            fat      REAL NOT NULL,
            fiber    REAL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS meals (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            date     TEXT NOT NULL,
            food_id  INTEGER NOT NULL,
            grams    REAL NOT NULL,
            FOREIGN KEY (food_id) REFERENCES foods(id)
        );

        CREATE TABLE IF NOT EXISTS goals (
            id         INTEGER PRIMARY KEY CHECK (id = 1),
            calories   REAL DEFAULT 2000,
            protein    REAL DEFAULT 150,
            carbs      REAL DEFAULT 200,
            fat        REAL DEFAULT 65,
            water_ml   REAL DEFAULT 2500
        );

        INSERT OR IGNORE INTO goals (id, calories, protein, carbs, fat, water_ml)
        VALUES (1, 2000, 150, 200, 65, 2500);

        CREATE TABLE IF NOT EXISTS activities (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            name           TEXT NOT NULL UNIQUE,
            kcal_per_hour  REAL NOT NULL
        );

        INSERT OR IGNORE INTO activities (name, kcal_per_hour) VALUES
            ('Trekking',       400),
            ('Mountain Bike',  550),
            ('Gym',            350),
            ('Sea Kayak',      400),
            ('Trail Running',  650);

        CREATE TABLE IF NOT EXISTS workouts (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            date         TEXT NOT NULL,
            activity_id  INTEGER NOT NULL,
            duration_min INTEGER NOT NULL,
            intensity    TEXT NOT NULL DEFAULT 'promedio',
            kcal_burned  REAL NOT NULL,
            FOREIGN KEY (activity_id) REFERENCES activities(id)
        );

        CREATE TABLE IF NOT EXISTS water_log (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            date  TEXT NOT NULL,
            ml    REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS weight_log (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            date  TEXT NOT NULL UNIQUE,
            kg    REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS daily_notes (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            date  TEXT NOT NULL UNIQUE,
            note  TEXT NOT NULL
        );
    """)
    # Migración segura: agregar water_ml a goals si no existe aún
    try:
        conn.execute("ALTER TABLE goals ADD COLUMN water_ml REAL DEFAULT 2500")
        conn.execute("UPDATE goals SET water_ml = 2500 WHERE water_ml IS NULL")
        conn.commit()
    except Exception:
        pass  # La columna ya existe
    conn.commit()
    conn.close()

# ──────────────────────────────────────────────
# INICIALIZAR DB AL ARRANCAR (necesario para gunicorn)
# ──────────────────────────────────────────────
init_db()

# ──────────────────────────────────────────────
# RUTAS
# ──────────────────────────────────────────────

@app.route("/")
def index():
    today = date.today().isoformat()
    conn = get_db()

    meals = conn.execute("""
        SELECT m.id, f.name, m.grams,
               ROUND(f.calories * m.grams / 100, 1) AS calories,
               ROUND(f.protein  * m.grams / 100, 1) AS protein,
               ROUND(f.carbs    * m.grams / 100, 1) AS carbs,
               ROUND(f.fat      * m.grams / 100, 1) AS fat,
               ROUND(f.fiber    * m.grams / 100, 1) AS fiber
        FROM meals m
        JOIN foods f ON f.id = m.food_id
        WHERE m.date = ?
        ORDER BY m.id
    """, (today,)).fetchall()

    totals = {
        "calories": sum(m["calories"] for m in meals),
        "protein":  sum(m["protein"]  for m in meals),
        "carbs":    sum(m["carbs"]    for m in meals),
        "fat":      sum(m["fat"]      for m in meals),
        "fiber":    sum(m["fiber"]    for m in meals),
    }

    goals    = conn.execute("SELECT * FROM goals WHERE id = 1").fetchone()

    # Calorías quemadas hoy → se suman al objetivo calórico
    burned_row = conn.execute(
        "SELECT ROUND(SUM(kcal_burned), 0) AS total FROM workouts WHERE date = ?", (today,)
    ).fetchone()
    kcal_burned = burned_row["total"] or 0

    workouts_today = conn.execute("""
        SELECT w.id, a.name, w.duration_min, w.intensity, w.kcal_burned
        FROM workouts w JOIN activities a ON a.id = w.activity_id
        WHERE w.date = ? ORDER BY w.id
    """, (today,)).fetchall()

    # Agua consumida hoy
    water_row = conn.execute(
        "SELECT ROUND(SUM(ml), 0) AS total FROM water_log WHERE date = ?", (today,)
    ).fetchone()
    water_consumed = water_row["total"] or 0

    # Objetivo de agua: base + 500ml extra si entrenó hoy
    water_goal = (goals["water_ml"] or 2500) + (500 if kcal_burned > 0 else 0)

    # Peso de hoy (si fue registrado)
    weight_row = conn.execute(
        "SELECT kg FROM weight_log WHERE date = ?", (today,)
    ).fetchone()
    today_weight = weight_row["kg"] if weight_row else None

    # Peso anterior para mostrar diferencia
    prev_weight_row = conn.execute(
        "SELECT kg FROM weight_log WHERE date < ? ORDER BY date DESC LIMIT 1", (today,)
    ).fetchone()
    prev_weight = prev_weight_row["kg"] if prev_weight_row else None

    # Nota del día
    note_row = conn.execute(
        "SELECT note FROM daily_notes WHERE date = ?", (today,)
    ).fetchone()
    today_note = note_row["note"] if note_row else ""

    conn.close()
    return render_template("index.html", meals=meals, totals=totals, today=today,
                           goals=goals, kcal_burned=kcal_burned, workouts_today=workouts_today,
                           water_consumed=water_consumed, water_goal=water_goal,
                           today_weight=today_weight, prev_weight=prev_weight,
                           today_note=today_note)


@app.route("/log", methods=["GET", "POST"])
def log_meal():
    conn = get_db()
    foods = conn.execute("SELECT id, name FROM foods ORDER BY name").fetchall()

    if request.method == "POST":
        food_id = request.form.get("food_id")
        grams   = request.form.get("grams")
        today   = date.today().isoformat()

        if not food_id or not grams:
            flash("Completá todos los campos.", "danger")
        else:
            conn.execute(
                "INSERT INTO meals (date, food_id, grams) VALUES (?, ?, ?)",
                (today, food_id, float(grams))
            )
            conn.commit()
            flash("✅ Ingesta registrada.", "success")
            conn.close()
            return redirect(url_for("index"))

    conn.close()
    return render_template("log_meal.html", foods=foods)


@app.route("/delete_meal/<int:meal_id>")
def delete_meal(meal_id):
    conn = get_db()
    conn.execute("DELETE FROM meals WHERE id = ?", (meal_id,))
    conn.commit()
    conn.close()
    flash("🗑️ Ingesta eliminada.", "info")
    return redirect(url_for("index"))


@app.route("/foods")
def list_foods():
    conn = get_db()
    foods = conn.execute("SELECT * FROM foods ORDER BY name").fetchall()
    conn.close()
    return render_template("foods.html", foods=foods)


@app.route("/foods/add", methods=["GET", "POST"])
def add_food():
    if request.method == "POST":
        name     = request.form.get("name", "").strip()
        calories = request.form.get("calories")
        protein  = request.form.get("protein")
        carbs    = request.form.get("carbs")
        fat      = request.form.get("fat")
        fiber    = request.form.get("fiber", 0)

        if not all([name, calories, protein, carbs, fat]):
            flash("Completá todos los campos obligatorios.", "danger")
        else:
            try:
                conn = get_db()
                conn.execute(
                    "INSERT INTO foods (name, calories, protein, carbs, fat, fiber) VALUES (?,?,?,?,?,?)",
                    (name, float(calories), float(protein), float(carbs), float(fat), float(fiber))
                )
                conn.commit()
                conn.close()
                flash(f"✅ '{name}' agregado a tu base de datos.", "success")
                return redirect(url_for("list_foods"))
            except sqlite3.IntegrityError:
                flash(f"Ya existe un alimento llamado '{name}'.", "warning")

    return render_template("add_food.html")


@app.route("/foods/delete/<int:food_id>")
def delete_food(food_id):
    conn = get_db()
    conn.execute("DELETE FROM foods WHERE id = ?", (food_id,))
    conn.execute("DELETE FROM meals WHERE food_id = ?", (food_id,))
    conn.commit()
    conn.close()
    flash("🗑️ Alimento eliminado.", "info")
    return redirect(url_for("list_foods"))


@app.route("/goals", methods=["GET", "POST"])
def goals_settings():
    conn = get_db()
    if request.method == "POST":
        calories = request.form.get("calories", 2000)
        protein  = request.form.get("protein", 150)
        carbs    = request.form.get("carbs", 200)
        fat      = request.form.get("fat", 65)
        conn.execute(
            "UPDATE goals SET calories=?, protein=?, carbs=?, fat=?, water_ml=? WHERE id=1",
            (float(calories), float(protein), float(carbs), float(fat), float(request.form.get("water_ml", 2500)))
        )
        conn.commit()
        flash("✅ Objetivos actualizados.", "success")
        conn.close()
        return redirect(url_for("index"))

    goals = conn.execute("SELECT * FROM goals WHERE id=1").fetchone()
    conn.close()
    return render_template("goals.html", goals=goals)


INTENSITY_MULTIPLIER = {"suave": 0.80, "promedio": 1.00, "intenso": 1.30}


@app.route("/weight/save", methods=["POST"])
def save_weight():
    kg = request.form.get("kg", "").strip()
    today = date.today().isoformat()
    if kg:
        conn = get_db()
        conn.execute(
            "INSERT INTO weight_log (date, kg) VALUES (?, ?) ON CONFLICT(date) DO UPDATE SET kg=excluded.kg",
            (today, float(kg))
        )
        conn.commit()
        conn.close()
    return redirect(url_for("index"))


@app.route("/weight/delete")
def delete_weight():
    today = date.today().isoformat()
    conn = get_db()
    conn.execute("DELETE FROM weight_log WHERE date = ?", (today,))
    conn.commit()
    conn.close()
    return redirect(url_for("index"))


@app.route("/note/save", methods=["POST"])
def save_note():
    note = request.form.get("note", "").strip()
    today = date.today().isoformat()
    conn = get_db()
    if note:
        conn.execute(
            "INSERT INTO daily_notes (date, note) VALUES (?, ?) "
            "ON CONFLICT(date) DO UPDATE SET note=excluded.note",
            (today, note)
        )
    else:
        conn.execute("DELETE FROM daily_notes WHERE date = ?", (today,))
    conn.commit()
    conn.close()
    return redirect(url_for("index"))


@app.route("/progress")
def progress():
    conn = get_db()
    weights = conn.execute(
        "SELECT date, kg FROM weight_log ORDER BY date ASC LIMIT 60"
    ).fetchall()
    notes = conn.execute(
        "SELECT date, note FROM daily_notes ORDER BY date DESC LIMIT 30"
    ).fetchall()
    goals = conn.execute("SELECT * FROM goals WHERE id=1").fetchone()
    conn.close()
    return render_template("progress.html", weights=weights, notes=notes, goals=goals)


@app.route("/water/add", methods=["POST"])
def add_water():
    ml = request.form.get("ml", 0)
    today = date.today().isoformat()
    conn = get_db()
    conn.execute("INSERT INTO water_log (date, ml) VALUES (?, ?)", (today, float(ml)))
    conn.commit()
    conn.close()
    return redirect(url_for("index"))

@app.route("/water/undo")
def undo_water():
    today = date.today().isoformat()
    conn = get_db()
    last = conn.execute(
        "SELECT id FROM water_log WHERE date = ? ORDER BY id DESC LIMIT 1", (today,)
    ).fetchone()
    if last:
        conn.execute("DELETE FROM water_log WHERE id = ?", (last["id"],))
        conn.commit()
    conn.close()
    return redirect(url_for("index"))



@app.route("/workouts/log", methods=["GET", "POST"])
def log_workout():
    conn = get_db()
    activities = conn.execute("SELECT * FROM activities ORDER BY name").fetchall()

    if request.method == "POST":
        activity_id  = request.form.get("activity_id")
        duration_min = request.form.get("duration_min")
        intensity    = request.form.get("intensity", "promedio")
        today        = date.today().isoformat()

        if not activity_id or not duration_min:
            flash("Completá todos los campos.", "danger")
        else:
            act = conn.execute("SELECT kcal_per_hour FROM activities WHERE id=?", (activity_id,)).fetchone()
            mult = INTENSITY_MULTIPLIER.get(intensity, 1.0)
            kcal = round(act["kcal_per_hour"] * mult * int(duration_min) / 60, 1)
            conn.execute(
                "INSERT INTO workouts (date, activity_id, duration_min, intensity, kcal_burned) VALUES (?,?,?,?,?)",
                (today, activity_id, int(duration_min), intensity, kcal)
            )
            conn.commit()
            flash(f"✅ Entrenamiento registrado — {kcal} kcal quemadas.", "success")
            conn.close()
            return redirect(url_for("index"))

    conn.close()
    return render_template("log_workout.html", activities=activities)


@app.route("/workouts/delete/<int:workout_id>")
def delete_workout(workout_id):
    conn = get_db()
    conn.execute("DELETE FROM workouts WHERE id=?", (workout_id,))
    conn.commit()
    conn.close()
    flash("🗑️ Entrenamiento eliminado.", "info")
    return redirect(url_for("index"))


@app.route("/activities")
def list_activities():
    conn = get_db()
    activities = conn.execute("SELECT * FROM activities ORDER BY name").fetchall()
    conn.close()
    return render_template("activities.html", activities=activities)


@app.route("/activities/add", methods=["GET", "POST"])
def add_activity():
    if request.method == "POST":
        name          = request.form.get("name", "").strip()
        kcal_per_hour = request.form.get("kcal_per_hour")
        if not name or not kcal_per_hour:
            flash("Completá todos los campos.", "danger")
        else:
            try:
                conn = get_db()
                conn.execute("INSERT INTO activities (name, kcal_per_hour) VALUES (?,?)",
                             (name, float(kcal_per_hour)))
                conn.commit()
                conn.close()
                flash(f"✅ '{name}' agregada.", "success")
                return redirect(url_for("list_activities"))
            except Exception:
                flash("Ya existe una actividad con ese nombre.", "warning")
    return render_template("add_activity.html")


@app.route("/activities/delete/<int:activity_id>")
def delete_activity(activity_id):
    conn = get_db()
    conn.execute("DELETE FROM activities WHERE id=?", (activity_id,))
    conn.execute("DELETE FROM workouts WHERE activity_id=?", (activity_id,))
    conn.commit()
    conn.close()
    flash("🗑️ Actividad eliminada.", "info")
    return redirect(url_for("list_activities"))


@app.route("/foods/scan", methods=["GET", "POST"])
def scan_label():
    """Recibe una imagen, la manda a Claude y devuelve los valores nutricionales en JSON."""
    if request.method == "GET":
        return render_template("scan_label.html")

    # ── POST: procesar la imagen ──
    if "image" not in request.files or request.files["image"].filename == "":
        return jsonify({"error": "No se recibió ninguna imagen."}), 400

    image_file = request.files["image"]
    image_bytes = image_file.read()
    image_b64 = base64.standard_b64encode(image_bytes).decode("utf-8")

    # Detectar tipo de imagen
    content_type = image_file.content_type or "image/jpeg"
    if content_type not in ("image/jpeg", "image/png", "image/webp", "image/gif"):
        content_type = "image/jpeg"

    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return jsonify({"error": "Falta la API key de Anthropic. Configurá la variable ANTHROPIC_API_KEY."}), 500

    try:
        client = anthropic.Anthropic(api_key=api_key)

        message = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=512,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": content_type,
                                "data": image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": (
                                "Esta es una foto de una etiqueta nutricional. "
                                "Extraé los valores nutricionales y devolvé ÚNICAMENTE un JSON válido "
                                "(sin texto extra, sin markdown, sin explicaciones) con estos campos:\n"
                                "{\n"
                                '  "name": "nombre del producto",\n'
                                '  "calories": número (kcal por 100g),\n'
                                '  "protein": número (g por 100g),\n'
                                '  "carbs": número (g por 100g),\n'
                                '  "fat": número (g por 100g),\n'
                                '  "fiber": número (g por 100g, 0 si no aparece)\n'
                                "}\n"
                                "Si los valores son por porción y no por 100g, convertílos a 100g. "
                                "Usá punto como separador decimal. Solo devolvé el JSON."
                            ),
                        },
                    ],
                }
            ],
        )

        raw = message.content[0].text.strip()
        # Limpiar posibles bloques de código markdown
        raw = raw.replace("```json", "").replace("```", "").strip()
        data = json.loads(raw)
        return jsonify(data)

    except json.JSONDecodeError:
        return jsonify({"error": "No pude interpretar la respuesta de la IA. Intentá con otra foto."}), 500
    except Exception as e:
        return jsonify({"error": f"Error al procesar la imagen: {str(e)}"}), 500


@app.route("/history")
def history():
    conn = get_db()
    dates = conn.execute("""
        SELECT m.date,
               ROUND(SUM(f.calories * m.grams / 100), 1) AS calories,
               ROUND(SUM(f.protein  * m.grams / 100), 1) AS protein,
               ROUND(SUM(f.carbs    * m.grams / 100), 1) AS carbs,
               ROUND(SUM(f.fat      * m.grams / 100), 1) AS fat
        FROM meals m
        JOIN foods f ON f.id = m.food_id
        GROUP BY m.date
        ORDER BY m.date DESC
        LIMIT 30
    """).fetchall()
    conn.close()
    return render_template("history.html", dates=dates)


# ──────────────────────────────────────────────
# INICIO
# ──────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
